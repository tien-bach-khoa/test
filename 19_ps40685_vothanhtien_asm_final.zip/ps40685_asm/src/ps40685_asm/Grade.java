/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ps40685_asm;

import java.text.DecimalFormat;

/**
 *
 * @author Tien
 */
public class Grade {
    private String maSV;
    private String name;
    private double tiengAnh;
    private double tinHoc;
    private double GDTC;
    private double avg;

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTiengAnh() {
        return tiengAnh;
    }

    public void setTiengAnh(double tiengAnh) {
        this.tiengAnh = tiengAnh;
    }

    public double getTinHoc() {
        return tinHoc;
    }

    public void setTinHoc(double tinHoc) {
        this.tinHoc = tinHoc;
    }

    public double getGDTC() {
        return GDTC;
    }

    public void setGDTC(double GDTC) {
        this.GDTC = GDTC;
    }

    public double getAvg() {
        DecimalFormat df = new DecimalFormat("#.##");
        this.avg = (getTiengAnh()+ getTinHoc()+ getGDTC())/ 3;
        return Double.parseDouble(df.format(this.avg));
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }
    
}
