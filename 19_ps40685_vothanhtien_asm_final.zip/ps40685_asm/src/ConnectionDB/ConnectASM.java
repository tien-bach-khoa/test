/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConnectionDB;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Tien
 */
public class ConnectASM {
    public static String user = "sa";
    public static String pass = "123456";
    public static String diverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String url = "jdbc:sqlserver://localhost\\LOCALHOST:1433;databaseName=ASM;encrypt=false;trustServerCertificate=true";
    public static Connection connection;
    public static Connection getConnection(){
        try{
            Class.forName(diverName);
            connection = DriverManager.getConnection(url, user, pass);
        }catch(Exception e){
            System.out.println(e);
        }
        
        
        return connection;
    }
}
